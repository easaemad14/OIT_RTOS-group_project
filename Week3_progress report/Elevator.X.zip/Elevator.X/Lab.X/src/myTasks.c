/*************************************************************
*
* Lab/Assignment: Lab2 ? Dynamic task assignment
* 
* Overview: (From lab handout)
*	This task will poll the status of the three switches and act accordingly. Each of the switches will cause
*   this behavior:
*   SW1:
*   The first time SW1 is pressed, LED1 will start flashing. The second press will start LED2, and finally,
*   the third press will start LED3 flashing. Any subsequent presses will not do anything. This will be
*   accomplished by doing a taskCreate for the next LED. Unlike last time, the task creation call must take
*   back the task handle, which was the last parameter in the call. It was set to NULL last time as the
*   handle was not needed. However, in this function, the handle (one for each LED task created) will be
*   necessary to delete the task. The task will toggle the appropriate LED and then do a taskDelay of 500
*   ms. This will be done using an RTOS call versus the busy wait that was implemented in the last lab.
*   SW2:
*   Each time SW2 is pressed, the highest LED flashing will stop. LEDs will stop until all of them have
*   stopped. After all the LEDs have stopped flashing, subsequent presses will do nothing. This will be
*   accomplished by deleting the highest flashing LED task. To delete a task, the task handle created
*   during the task creation is used. After deleting a task SW1 can restart it, so if all three LEDs were
*   blinking then SW1 did nothing. If SW2 is pressed LED3 would stop blinking, SW1 would once again
*   start this task blinking.
*   SW3:
*   A press of SW3 will ?freeze? all current flashing LEDs. If fewer than three LEDs are currently
*   flashing, SW1 will have the opportunity to cause any higher LEDs to start flashing as described above.
*   A second press of SW3 will ?unfreeze? the frozen LEDs. This is accomplished by suspending all
*   currently running LED tasks on the ?first? button press. The second button press will resume all created
*   LED tasks.
*   The polling of the switches will happen in sequence and actions will be taken accordingly. After all
*   three switches have been polled, the task will perform a taskDelay for 100ms.
*
* Input:
*   The input will come via the three STARTER KIT switches SW1 (RD6),
*   SW2 (RD7) and SW3 (RD13)... 
*   The switches are raw and simply ground the respective Port D pin when
*   pressed. They do not have external pullups and they not debounced.
*   Both of these issues must be addressed by the software.
*   The first issue of pullups is handled by enabling the PIC32-provided
*   internal pullups that are part of the Change Notification (CN)
*   peripheral. Only the pin references that specify a CNx notion have this
*   capability, such as those pins used for the STARTER KIT switches as
*   illustrated in the Figure. You will notice that RD6 is associated with
*   CN15, RD7 with CN16, and RD13 with CN19. These CN pins will
*   need to have their pullups enabled. This PIC32 C environment provides
*   a macro that performs the enable function in a similar way to interacting
*   with the Port bits themselves. 
*
* Output:
*	LEDs will begin flashing on the board according to the patterns and inputs stated
*   in the Overview section above.
*
************************************************************/

#include "myTasks.h"

// Creating a flag to separate production code from whatever else I need just
// simulate coms from other tasks and variables. comment out to make ready for release
//
#define DEBUG_MODE



/*above header has the following definitions:
  
typedef uint8_t bool_t;
#define TRUE  255
#define FALSE 0

#define NUM_LEDS 3

#define SW1     0x40    //RD6
#define SW2     0x80    //RD7
#define SW3     0x2000  //RD13
#define PRESSED 0       //Active low
 
#define PORT_MASK   //value declared in header    //Only need the switches 
 */

/*
 * All tasks will be instantiated for the momnet with unused paramters.
 
 */

// Function (not task) to assemble the queues, semaphores and any other 
// necessary interprocess communication for the 
//
void SetupQueuesAndStuff(void)
{
    
}

void MoveTask(void * params)
{
    
}

void SetupLift(void)
{
    
}

void DoorTask(void * usused)
{
    
}

void BuildDoors(void)
{
    
}

void InitElevator(void * unused)
{
    // Init functions all go here
    //

    // Deletes itself when finished with setup.
    //
    vTaskDelete(NULL);
}